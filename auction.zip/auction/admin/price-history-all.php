<?php 
include 'header-admin.php';
session_start();
include'dbconnection.php';
if (strlen($_SESSION['id']==0)) {
  header('location:logout.php');
} else{
// for deleting price
if(isset($_GET['id'])){
	$priceId = $_GET['id'];
	$message = mysqli_query($con,"delete from price where id='$priceId'");
	if($message){
		$_SESSION['message'] = 'Price detail deleted successfully.';
		$_SESSION['color'] = '#008000';
	}
}
?>
		<section id="main-content">
			<section class="wrapper">
				<h3><i class="fa fa-angle-right"></i> Price history</h3>
				<div class="row">
					<?php if(isset($_SESSION['message'])) { ?>
						<p style="color:<?php echo $_SESSION['color'] ?>;margin-left: 25px;">
							<?php 
								echo $_SESSION['message']; 
								$_SESSION['message'] = ''; 
								$_SESSION['color'] = '';
							?>
						</p>
					<?php } ?>
					<div class="col-md-12">
						<div class="content-panel">
							<table class="table table-striped table-advance table-hover">
								<h4><i class="fa fa-angle-right"></i>All price history</h4>
								<hr>
								<thead>
									<tr>
										<th>Sno.</th>
										<th class="hidden-phone">Date</th>
										<th>Auctioneer</th>
										<th>Cardamom Type</th>
										<th>Minimum price</th>
										<th>Maximim price</th>
										<th>Average price</th>
										<th>No of Kgs sold</th>
									</tr>
								</thead>
								<tbody>
									<?php $ret = mysqli_query($con,"select * from price order by id desc");
									$cnt = 1;
									while($row=mysqli_fetch_array($ret)) { ?>
									<tr>
										<td><?php echo $cnt;?></td>
										<td><?php echo $row['date'];?></td>
										<td><?php echo $row['auctioneer'];?></td>
										<td><?php echo $row['cardamom_type'];?></td>
										<td><?php echo $row['minimum_price'];?></td>  
										<td><?php echo $row['maximum_price'];?></td>
										<td><?php echo $row['average_price'];?></td>
										<td><?php echo $row['no_of_kgs_sold'];?></td>
										
										<td>
											<a href="update-price.php?id=<?php echo $row['id'];?>"> 
												<button class="btn btn-primary btn-xs"><i class="fa fa-pencil"></i></button>
											</a>
											<a href="price-history-all.php?id=<?php echo $row['id'];?>">
												<button class="btn btn-danger btn-xs" onClick="return confirm('Do you really want to delete this price?');"><i class="fa fa-trash-o "></i></button>
											</a>
										</td>
									</tr>
									<?php $cnt = $cnt+1; } ?>
								</tbody>
							</table>
						</div>
					</div>
				</div>
			</section>
		</section>
</body>
</html>
<?php } ?>