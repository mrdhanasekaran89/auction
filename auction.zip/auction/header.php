<?php
session_start();
?>
<!DOCTYPE html>
<html lang="">
<head>
<title>Auction</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<link href="layout/styles/layout.css" rel="stylesheet" type="text/css" media="all">
</head>
<body id="top">

<div class="wrapper row0">
  <header id="header" class="hoc clear"> 
    <div id="logo" class="one_quarter first">
      <h1 class="logoname clear"><a href="index.php"><span>Auction</span></a></h1><p>&nbsp;</p>
      <p>Cardamom Auction Management</p>
    </div>
    <div class="three_quarter">
      <ul class="nospace clear">
        <li class="one_third first">
          <div class="block clear"><i class="fas fa-phone"></i><span><strong>Give us a call:</strong> +91 9876543210</span></div>
        </li>
        <li class="one_third">
          <div class="block clear"><i class="fas fa-envelope"></i><span><strong>Send us a mail:</strong> support@auction.com</span></div>
        </li>
        <li class="one_third">
          <div class="block clear"><i class="fas fa-clock"></i><span><strong> Mon. - Sat.:</strong> 08.00am - 8.00pm</span></div>
        </li>
      </ul>
    </div>
  </header>
</div>
<div class="wrapper row1">
  <div class="hoc clear">
    <nav id="mainav">
      <ul class="clear">
        <li><a href="index.php">Home</a></li>
        <li><a href="about.php">About us</a></li>
				<li><a href="services.php">Our Services</a></li>		
				<li><a href="blog.php">Blog</a></li>		
        
				<li><a class="drop" href="#">Auction Price</a>
					<ul>
						<li><a href="price_list_small.php">Small Cardamom</a></li>
						<li><a href="price_list_big.php">Big Cardamom</a></li>
					</ul>
				</li>
				<li><a href="contact.php">Contact us</a></li>
				<?php if (!isset($_SESSION['id'])) { ?>
				<li><a class="drop">Account</a>
					<ul>
							<li><a href="registration.php">Register</a></li>
							<li><a href="login.php">Login</a></li>
							<li><a href="reset-password.php">Reset password</a></li>
					</ul>
				</li>
				<?php } else { ?>
					<li><a class="drop" href="#"><?php echo isset($_SESSION['name'])? $_SESSION['name']: 'My account';?></a>
						<ul>
							<li><a href="view_profile.php?uid=<?php echo $_SESSION['id']; ?>">View profile</a></li>
							<li><a href="submit_price.php">Submit Cardamom price</a></li>
							<li><a href="manage_my_prices.php">Manage my price details</a></li>
							<li><a href="logout.php">Logout</a></li>
						</ul>
					</li>
				<?php } ?>
      </ul>
    </nav>
  </div>
</div>