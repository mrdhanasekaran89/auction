<?php include 'header.php';
require_once('dbconnection.php');

if(isset($_POST['login'])) {
	$password = $_POST['password'];
	$dec_password = md5($password);
	$useremail = $_POST['uemail'];
	$res = mysqli_query($con,"SELECT * FROM users WHERE email='$useremail' and password='$dec_password'");
	$num = mysqli_fetch_array($res);
	if($num > 0){
		$extra="index.php";
		$_SESSION['login'] = $_POST['uemail'];
		$_SESSION['id'] = $num['id'];
		$_SESSION['name'] = $num['fname'];
		$host = $_SERVER['HTTP_HOST'];
		$uri = rtrim(dirname($_SERVER['PHP_SELF']),'/\\');
		header("location:http://$host$uri/$extra");
		exit();
	} else {
		$_SESSION['message'] = 'Invalid username or password';
		$_SESSION['color'] = '#F00';		
	}
}

?>

<div class="wrapper bgded overlay dark" style="background-image:url('../images/demo/backgrounds/01.png');">
  <div id="breadcrumb" class="hoc clear">
    <h6 class="heading">Login form</h6>
  </div>
</div>
<div class="register-login-intro">
	<p>Spices Board (Ministry of Commerce and Industry, Government of India) is the flagship organization for the development and worldwide promotion of Indian spices. The Board is an international link between the Indian exporters and the importers abroad. 
	The Board has been spearheading activities for excellence of Indian spices, involving every segment of the industry.By registering into the site, you will be able to post price details everyday.</p>
	<p>Spices Board has set up a state-of-the-art Quality Evaluation Lab (QEL) at Navi Mumbai for pesticide residue analysis and microbial food safety in spices and spice products. 
	The QEL building is the first-ever pre-engineered structure designed and built to perfection by a government organisation. The laboratory is equipped with latest immuno, molecular, biochemical and spectroscopic instrumental techniques for the detection and enumeration of micro-organisms in food. 
	A centre of excellence to decontaminate the pesticide residue in spices, QEL Mumbai has elevated the services to meet the global standards and export quality spices.
	</p>
</div>
<div class="wrapper row3 custom_form">
		<form name="login" class="login" action="" method="post">
			<?php if(isset($_SESSION['message'])) { ?>
			<p style="color:<?php echo $_SESSION['color'] ?>;margin-left: 25px;">
				<?php 
					echo $_SESSION['message']; 
					$_SESSION['message'] = ''; 
					$_SESSION['color'] = '';
				?>
			</p>
		<?php } ?>
			<p>Enter your registered email </p>
			<input type="text" class="text" value=""  name="uemail" required >
			<p>Enter valid password </p>
			<input type="password" class="text" value="" name="password"  required >

			<input type="submit" name="login" style="margin:12px 0" value="LOG IN" >

		</form>
</div>
<?php include 'footer.php'; ?>