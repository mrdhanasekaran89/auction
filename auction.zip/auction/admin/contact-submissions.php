<?php 
include 'header-admin.php';
session_start();
include'dbconnection.php';
if (strlen($_SESSION['id']==0)) {
  header('location:logout.php');
} else{
?>
		<section id="main-content">
			<section class="wrapper">
				<h3><i class="fa fa-angle-right"></i>Contact history</h3>
				<div class="row">
					<div class="col-md-12">
						<div class="content-panel">
							<table class="table table-striped table-advance table-hover">
								<h4><i class="fa fa-angle-right"></i>All Contact history</h4>
								<hr>
								<thead>
									<tr>
										<th>Sno.</th>
										<th class="hidden-phone">Date</th>
										<th>First name</th>
										<th>Last name</th>
										<th>Email</th>
										<th>Phone</th>
										<th>Message</th>
									</tr>
								</thead>
								<tbody>
									<?php $ret = mysqli_query($con,"select * from contact order by id desc");
									$cnt = 1;
									while($row=mysqli_fetch_array($ret)) { ?>
									<tr>
										<td><?php echo $cnt;?></td>
										<td><?php echo $row['date'];?></td>
										<td><?php echo $row['first_name'];?></td>
										<td><?php echo $row['last_name'];?></td>
										<td><?php echo $row['email'];?></td>  
										<td><?php echo $row['phone'];?></td>
										<td><?php echo $row['message'];?></td>
									</tr>
									<?php $cnt = $cnt+1; } ?>
								</tbody>
							</table>
						</div>
					</div>
				</div>
			</section>
		</section>
</body>
</html>
<?php } ?>