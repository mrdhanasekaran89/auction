<?php include 'header.php';
require_once('dbconnection.php');
if (isset($_SESSION['id'])) {
  header('location:logout.php');
} else{
//Code for Registration 
if(isset($_POST['signup'])){
	if($_POST['password'] != $_POST['conf_password']){
		$_SESSION['message'] = 'Password and confirm password should be same';
		$_SESSION['color'] = '#F00';
	}else {
		$email = $_POST['email'];
		$res = mysqli_query($con,"SELECT * FROM users WHERE email='$email'");
		$email_exist = mysqli_fetch_array($res);		
		if($email_exist > 1){
			$_SESSION['message'] = 'Email already exist. Use some other email to register again.';
			$_SESSION['color'] = '#F00';
		}else{
			$fname = $_POST['fname'];
			$lname = $_POST['lname'];
			
			$password = md5($_POST['password']);
			$contact = $_POST['contact'];
			$enc_password = $password;
			
			$success = mysqli_query($con,"insert into users(fname,lname,email,password,contactno) values('$fname','$lname','$email','$enc_password','$contact')");
			if($success){
				$_SESSION['message'] = 'Registration successfull.';
				$_SESSION['color'] = '#008000';
			}
		}
	}
}

?>

<div class="wrapper bgded overlay dark" style="background-image:url('../images/demo/backgrounds/01.png');">
  <div id="breadcrumb" class="hoc clear">
    <h6 class="heading">Registration form</h6>    
  </div>
</div>
<div class="register-login-intro">
	<p>Spices Board (Ministry of Commerce and Industry, Government of India) is the flagship organization for the development and worldwide promotion of Indian spices. The Board is an international link between the Indian exporters and the importers abroad. 
	The Board has been spearheading activities for excellence of Indian spices, involving every segment of the industry.By registering into the site, you will be able to post price details everyday.</p>
	<p>Spices Board has set up a state-of-the-art Quality Evaluation Lab (QEL) at Navi Mumbai for pesticide residue analysis and microbial food safety in spices and spice products. 
	The QEL building is the first-ever pre-engineered structure designed and built to perfection by a government organisation. The laboratory is equipped with latest immuno, molecular, biochemical and spectroscopic instrumental techniques for the detection and enumeration of micro-organisms in food. 
	A centre of excellence to decontaminate the pesticide residue in spices, QEL Mumbai has elevated the services to meet the global standards and export quality spices.
	</p>
</div>
<div class="wrapper row3 custom_form">
		<form name="registration" class="registration" method="post" action="" enctype="multipart/form-data">
			<?php if(isset($_SESSION['message'])) { ?>
			<p style="color:<?php echo $_SESSION['color'] ?>;margin-left: 25px;">
				<?php 
					echo $_SESSION['message']; 
					$_SESSION['message'] = ''; 
					$_SESSION['color'] = '';
				?>
			</p>
		<?php } ?>
			<p>First Name </p>
			<input type="text" class="text" value=""  name="fname" required >
			<p>Last Name </p>
			<input type="text" class="text" value="" name="lname"  required >
			<p>Email Address </p>
			<input type="email" class="text" value="" name="email"  >
			<p>Password </p>
			<input type="password" value="" name="password" required>
			<p>Confirm Password </p>
			<input type="password" value="" name="conf_password" required>
					<p>Phone No (10 Digits). </p>
			<input pattern="[0-9]{10}" type="tel" value="" name="contact"  required>
			<div class="sign-up" style="margin:12px 0">
				<input type="submit" name="signup"  value="Sign Up" >
				<div class="clear"> </div>
			</div>
		</form>
</div>
<?php include 'footer.php'; } ?>