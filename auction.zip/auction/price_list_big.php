<?php include 'header.php';
	require_once('dbconnection.php');
	$result = mysqli_query($con,"select * from price where cardamom_type='big' order by id desc");
	
	$limit = 20;   
	if (isset($_GET["page"])) {
		$pn  = $_GET["page"];  
	}  
	else {  
		$pn=1;  
	};   

	$start_from = ($pn-1) * $limit;
	
	$result = mysqli_query($con,"select * from price where cardamom_type='big' order by id desc LIMIT $start_from, $limit");
		
?>

<!-- inner page banner -->
<div id="inner_banner" class="inner_banner_section">
  <div class="about-container">
    <div class="row">
      <div class="col-md-12">
        <div class="full">
          <div class="title-holder">
            <div class="title-holder-cell text-left">
              <h1 class="page-title">Cardamom price Big</h1>
              <ol class="breadcrumb">
                <li><a href="index.php">Home</a></li>
                <li class="active">Cardamom price Big</li>
              </ol>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- end inner page banner -->

<section class="price-intro">
	<div class="list">
		 <div class="content">
				<h4>Our auctions work on all devices.</h4>
				<p>Cardamom has a fresh and aromatic aroma which is complex in nature. It can be described as slightly sweet, floral, and spicy with citric elements.</p>
				<p>Camphor is easily discernible in its odour which gives a strong smoky flavour. It persuasive essay 5 paragraph pay someone to write your essay leaves the tongue with a warm antiseptic sensation similar to eucalyptus and a pepper like after taste.</p>
				<p>The essential oil in the seeds contain a-terpineol 45%, myrcene 27%, limonene 8%, menthone 6%, ß-phellandrene 3%, 1,8-cineol 2%, sabinene 2% and heptane 2%.</p>
				<a href="contact.php">
					 <button>Contact us</button>
				</a>
		 </div>
		
	</div>
</section>

<!-- list starts here -->

<section id="main-content">
	<section class="wrapper">		
			<div class="row">
				<table class="table table-striped table-advance table-hover">
					<thead>
						<tr>
							<td>Date</td>
							<td>Auctioneer</td>
							<td>Minimum Price</td>
							<td>Maximum Price</td>
							<td>Average Price</td>
							<td>No of KGs sold</td>
						</tr>
					</thead>
					<tbody>								
						<?php while($row = $result->fetch_assoc()) { 
							$uid = $row['uid'];
						?>
								<tr><td><?php echo $row['date']; ?></td>
								<td><a href="view_profile.php?uid=<?php echo $uid; ?>"><?php echo $row['auctioneer']; ?></a></td>
								<td><?php echo $row['minimum_price']; ?></td>
								<td><?php echo $row['maximum_price']; ?></td>
								<td><?php echo $row['average_price']; ?></td>
								<td><?php echo $row['no_of_kgs_sold']; ?></td></tr>
						<?php	} ?>
					</tbody>							
				</table>
			</div>
			<ul class="pagination"> 
				<?php   
					$result = mysqli_query($con,"select count(*) from price where cardamom_type='big'");
					$row = $result->fetch_row();							
					$total_records = $row[0];   
					$total_pages = ceil($total_records / $limit); 
					$k = (($pn+9>$total_pages)?$total_pages-9:(($pn-9<1)?10:$pn));
					$pagLink = ""; 
					if($pn>=2){
							echo "<li><a href='price_list_small.php?page=1'> << </a></li>"; 
							echo "<li><a href='price_list_small.php?page=".($pn-1)."'> < </a></li>"; 
					} 
					for ($i=-2; $i<=2; $i++) {
						if($k+$i >0 && $k+$i <= $total_pages){
							if($k+$i==$pn) 
								$pagLink .= "<li class='active'><a href='price_list_small.php?page=".($k+$i)."'>".($k+$i)."</a></li>"; 
							else
								$pagLink .= "<li><a href='price_list_small.php?page=".($k+$i)."'>".($k+$i)."</a></li>";
						}
					}
					echo $pagLink; 
					if($pn<$total_pages){ 
							echo "<li><a href='price_list_small.php?page=".($pn+1)."'> > </a></li>"; 
							echo "<li><a href='price_list_small.php?page=".$total_pages."'> >> </a></li>"; 
					}     
				?>
			</ul>
	</section>
</section>
<?php include 'footer.php'; ?>