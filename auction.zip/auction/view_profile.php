<?php include 'header.php';
	require_once('dbconnection.php');
	$uid = $_GET['uid'];
	$result = mysqli_query($con,"select * from users where id=$uid");		
?>

<!-- inner page banner -->
<div id="inner_banner" class="inner_banner_section">
  <div class="about-container">
    <div class="row">
      <div class="col-md-12">
        <div class="full">
          <div class="title-holder">
            <div class="title-holder-cell text-left">
              <h1 class="page-title">View profile</h1>
              <ol class="breadcrumb">
                <li><a href="index.php">Home</a></li>
                <li class="active">View profile</li>
              </ol>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- end inner page banner -->

<!-- list starts here -->
<section id="main-content">
	<section class="wrapper">
			<div class="row">
				<table class="table table-striped table-advance table-hover">					
					<tbody>								
						<?php while($row = $result->fetch_assoc()) { ?>
								<tr><td>First name</td><td><?php echo $row['fname']; ?></td></tr>
								<tr><td>Last name</td><td><?php echo $row['lname']; ?></td></tr>
								<tr><td>Email</td><td><?php echo $row['email']; ?></td></tr>
								<tr><td>Phone</td><td><?php echo $row['contactno']; ?></td></tr>
						<?php	} ?>
					</tbody>							
				</table>
			</div>			
	</section>
</section>
<?php include 'footer.php'; ?>