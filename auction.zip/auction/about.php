<?php include 'header.php'; ?>
<!-- inner page banner -->
<div id="inner_banner" class="inner_banner_section">
  <div class="about-container">
    <div class="row">
      <div class="col-md-12">
        <div class="full">
          <div class="title-holder">
            <div class="title-holder-cell text-left">
              <h1 class="page-title">About Us</h1>
              <ol class="breadcrumb">
                <li><a href="index.php">Home</a></li>
                <li class="active">About Us</li>
              </ol>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- end inner page banner -->
<!-- section -->
<div class="section padding_layout_1">
  <div class="about-container">
    <div class="row">
      <div class="col-md-12">
        <div class="full">
          <div class="main_heading text_align_center">
            <h2>We are Auction Manager</h2>
            <p class="large">Fastest Auctioning service with best price!</p>
          </div>
        </div>
      </div>
    </div>
    <div class="row about_blog">
      <div class="col-lg-6 col-md-6 about_cont_blog">
        <div class="full text_align_left">
          <h3>What we do</h3>
          <p>Cardamom procured by farmers would undergo a series of quality tests, to meet international specifications and standards, without any compromise in quality. Moreover, as cardamom has been procured selectively from planters, at the own auctions of the company, the quality of cardamom has been ensured, at the time of procurement itself.</p>
          <ul>
            <li>Manage Auctioneers</li>
						<li>Guide the farmers</li>
						<li>Helping farmer</li>
						<li>Guiding Auctioneers</li>
          </ul>
        </div>
      </div>
      <div class="col-lg-6 col-md-6 about_feature_img padding_right_0">
        <div class="full text_align_center" style="margin: 60px 0;"> <img class="img-responsive" src="https://www.sigccltd.com/wp-content/uploads/2018/11/Pouch-Spice-mist-1.jpeg" alt="#" /> </div>
      </div>
    </div>
    
  </div>
</div>
<!-- end section -->

<div class="constitution about-container">
	<div class="content">
   <div class="field field-name-body field-type-text-with-summary field-label-hidden">
      <div class="field-items">
         <div class="field-item even" property="content:encoded">
            <p><strong>Constitution</strong></p>
            <p>Spices Board was constituted on 26th February 1987 under the Spices Board Act 1986 (No. 10 of 1986) with the merger of the erstwhile Cardamom Board (1968) and Spices Export Promotion Council (1960). Spices Board is one of the five Commodity Boards functioning under the Ministry of Commerce &amp; Industry. It is an autonomous body responsible for the export promotion of the 52 scheduled spices and development of Cardamom (Small &amp; Large).</p>
            <p><strong>Main Functions</strong></p>
            <ul>
               <li>Research, Development and Regulation of domestic marketing of Small &amp; Large Cardamom</li>
               <li>Post-harvest improvement of all spices</li>
               <li>Promotion of organic production, processing and certification of spices</li>
               <li>Development of spices in the North East</li>
               <li>Provision of quality evaluation services</li>
               <li>
                  Export promotion of all spices through support for:-
                  <ul>
                     <li>Technology upgradation.</li>
                     <li>Quality upgradation</li>
                     <li>Brand promotion</li>
                     <li>Research &amp; product development</li>
                  </ul>
               </li>
            </ul>
            <p><strong>Other responsibilities related to export promotion of spices:</strong></p>
            <ul>
               <li>Quality certification and control</li>
               <li>Registration of exporters</li>
               <li>Collection &amp; documentation of trade information</li>
               <li>Provision of inputs to the Central Government on policy matters relating to import &amp; export of spices</li>
            </ul>
            <p><strong>Multi-faceted activities</strong></p>
            <ul>
               <li>Promotion of exports of spices and spice products</li>
               <li>Maintenance and monitoring of quality of exports</li>
               <li>Development and implementation of better production methods, through scientific, technological and economic research.</li>
               <li>Guidance to farmers on getting higher and better quality yields through scientific agricultural practices.</li>
               <li>Provision of financial and material support to growers.</li>
               <li>Encouraging organic production and export of spices.</li>
               <li>Facilitating infrastructure for processing and value addition</li>
               <li>Registration and licensing of all spice exporters.</li>
               <li>Assistance for studies and research on better processing practices, foolproof quality management systems, improved grading methods and effective packaging techniques.</li>
               <li>Production of promotional and educative materials in a variety of media for the benefit of exporters and importers.</li>
            </ul>
            <p><strong>Package of services for exporters/importers</strong></p>
            <ul>
               <li>Helps exporters and importers in establishing mutual contact.</li>
               <li>Identifies competent supply sources for specific requirements of importers</li>
               <li>Processes and forwards foreign trade enquiries to reliable exporters.</li>
               <li>Organises a common platform for interaction between Indian exporters and international buyers through participation in major international exhibitions and meetings.</li>
               <li>Examine complaints from importers for corrective and preventive action</li>
               <li>Spearheads the quality improvement programme for Indian spices.</li>
               <li>Manages a comprehensive and up-to-date data bank for exporters and importers.</li>
               <li>Brings together international bodies, exporters and policy makers through contact group programmes.</li>
               <li>Makes India’s presence felt in major international food fairs; conducts food festivals and cooking demonstrations.</li>
            </ul>            
         </div>
      </div>
   </div>
</div>
</div>

<div class="about-container">
    <div class="row">
      <div class="col-md-12">
        <div class="full">
          <div class="contact_us_section">
            <div class="inner_cont">
              <h2>Do you have any Queries to clarify?</h2>
              <p>Please feel free to reach to us by posting your queries in the Contact us page. We are happy to help you!</p>
            </div>
            <div class="button_Section_cont"> <a class="btn dark_gray_bt" href="contact.php">Contact us</a> </div>
          </div>
        </div>
      </div>
    </div>
  </div>

<!-- Modal -->
<div class="modal fade" id="search_bar" role="dialog">
  <div class="modal-dialog">
    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
      </div>
    </div>
  </div>
</div>
<!-- End Model search bar -->
<?php include 'footer.php'; ?>