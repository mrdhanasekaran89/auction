<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="Dashboard">
    <meta name="keyword" content="Dashboard, Bootstrap, Admin, Template, Theme, Responsive, Fluid, Retina">

    <title>Admin | Manage Cardamom auction website</title>
    <link href="css/style.css" rel="stylesheet">
  </head>

  <body>

<section id="container" >
	<header class="header black-bg">
		<div class="sidebar-toggle-box">
			<div class="fa fa-bars tooltips" data-placement="right" data-original-title="Toggle Navigation"></div>
		</div>
		<a href="#" class="logo"><b>Admin Dashboard</b></a>
		<div class="nav notify-row" id="top_menu"></ul></div>
		<div class="top-menu">
			<ul class="nav pull-right top-menu">
				<li><a class="logout" href="logout.php">Logout</a></li>
			</ul>
		</div>
	</header>
<aside>
	<div id="sidebar"  class="nav-collapse ">
		<ul class="sidebar-menu" id="nav-accordion">
			<p class="centered"><a href="#"><img src="assets/img/ui-sam.jpg" class="img-circle" width="60"></a></p>
			<h5 class="centered"><?php echo $_SESSION['login'];?></h5>

			<li class="sub-menu">
				<a href="manage-users.php" >					
					<span>Manage Users</span>
				</a>

				<a href="price-history-all.php" >					
					<span>Manage Price details</span>
				</a>
				
				<a href="contact-submissions.php" >					
					<span>Contact submissions</span>
				</a>
				
				<a href="add-blog.php" >					
					<span>Submit a Blog</span>
				</a>
				
				<a href="manage-blogs.php" >					
					<span>Manage Blogs</span>
				</a>				
			</li>
			
		</ul>
	</div>
</aside>