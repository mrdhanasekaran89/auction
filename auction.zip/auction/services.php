<?php include 'header.php'; ?>

<div class="wrapper bgded overlay light" style="background: #039ee3;">
  <section id="cta" class="hoc container clear">
    <h6 class="three_quarter first">Auction Management - Our services</h6>
    <footer class="one_quarter"><a class="btn" href="contact.php">Contact us</a></footer>
  </section>
</div>

<div class="wrapper row3">
  <section id="team" class="hoc container clear">
    <div class="center btmspace-80">
      <h6 class="heading underline font-x2">Our services</h6>
    </div>
    <ul class="nospace group">
      <li class="one_quarter first">
        <article>
          <figure>
            <figcaption class="heading">Manage Auctioneers</figcaption>
          </figure>
          <em>Sub heading 1</em>
          <p>Cardamom procured by farmers would undergo a series of quality tests, to meet international specifications and standards, without any compromise in quality. Moreover, as cardamom has been procured selectively from planters.</p>          
        </article>
      </li>
      <li class="one_quarter">
        <article>
          <figure>
            <figcaption class="heading">Guide the farmers</figcaption>
          </figure>
          <em>Sub heading 2</em>
          <p>Cardamom procured by farmers would undergo a series of quality tests, to meet international specifications and standards, without any compromise in quality. Moreover, as cardamom has been procured selectively from planters.</p>
        </article>
      </li>
      <li class="one_quarter">
        <article>
          <figure>
            <figcaption class="heading">Helping farmer</figcaption>
          </figure>
          <em>Sub heading 3</em>
          <p>Cardamom procured by farmers would undergo a series of quality tests, to meet international specifications and standards, without any compromise in quality. Moreover, as cardamom has been procured selectively from planters.</p>
        </article>
      </li>
      <li class="one_quarter">
        <article>
          <figure>
            <figcaption class="heading">Guiding Auctioneers</figcaption>
          </figure>
          <em>Sub heading 4</em>
          <p>Cardamom procured by farmers would undergo a series of quality tests, to meet international specifications and standards, without any compromise in quality. Moreover, as cardamom has been procured selectively from planters.</p>
        </article>
      </li>
    </ul>
  </section>
</div>
<div class="wrapper row3">
  <section id="testimonials" class="hoc container clear">
    <div class="center btmspace-80">
      <h6 class="heading underline font-x2">Top comments from Auctioneers</h6>
    </div>
    <ul class="nospace group btmspace-80">
      <li class="one_third first">
        <blockquote>Excellent service, fast responses, product delivered as expected. Have bought items multiple times and very happy with services. Communications are exceptional.</blockquote>
        <figure class="clear">
          <figcaption>
            <h6 class="heading">Auctioneer 1</h6>
            <em>CEO / Company Name</em></figcaption>
        </figure>
      </li>
      <li class="one_third">
        <blockquote>Your service was excellent and very FAST. Many thanks for you kind and efficient service. I have already and will definitely continue to recommend your services.</blockquote>
        <figure class="clear">
          <figcaption>
            <h6 class="heading">Auctioneer 2</h6>
            <em>Director / Company Name</em></figcaption>
        </figure>
      </li>
      <li class="one_third">
        <blockquote>Its a great experience with how this company doing business , trustworthy and quick respond if you have any question , very ! Very happy the next day delivery.</blockquote>
        <figure class="clear">
          <figcaption>
            <h6 class="heading">Auctioneer 3</h6>
            <em>Marketing / Company Name</em></figcaption>
        </figure>
      </li>
    </ul>
  </section>
</div>
<?php include 'footer.php'; ?>