<?php 
include 'header-admin.php';
session_start();
include'dbconnection.php';
if (strlen($_SESSION['id']==0)) {
	header('location:logout.php');
} else{
	// for adding blog info    
	if(isset($_POST['Submit'])) {
		$title = $_POST['title'];
		$description = $_POST['description'];		
		
		$success = mysqli_query($con,"insert into `blog`(`title`, `description`) values('$title','$description')");
	
		$_SESSION['message'] = 'Blog added successfully.';
		$_SESSION['color'] = '#008000';
	}
?>
		
			<section id="main-content">
				<section class="wrapper">
					<h3><i class="fa fa-angle-right"></i>Submit a Blog</h3>
					<div class="row">
						<div class="col-md-12">
							<div class="content-panel">
								<form class="form-horizontal style-form" name="form1" method="post" action="" onSubmit="return valid();">
									<?php if(isset($_SESSION['message'])) { ?>
										<p style="color:<?php echo $_SESSION['color'] ?>;margin-left: 25px;">
											<?php 
												echo $_SESSION['message']; 
												$_SESSION['message'] = ''; 
												$_SESSION['color'] = '';
											?>
										</p>
									<?php } ?>									

									<div class="form-group">
										<label class="col-sm-2 col-sm-2 control-label" style="padding-left:40px;">Title</label>
										<div class="col-sm-10">
											<input type="text" class="form-control" name="title">
										</div>
									</div>
									
									<div class="form-group">
										<label class="col-sm-2 col-sm-2 control-label" style="padding-left:40px;">Description</label>
										<div class="col-sm-10">
											<textarea rows="10" class="form-control" name="description" required ></textarea>
										</div>
									</div>
									
									<div style="margin-left:100px;">
										<input type="submit" name="Submit" value="Submit" class="btn btn-theme">
									</div>
									
								</form>
							</div>
						</div>
					</div>
				</section>
		</section>
</body>
</html>
<?php } ?>