<?php 
include 'header-admin.php';
session_start();
include'dbconnection.php';
if (strlen($_SESSION['id']==0)) {
	header('location:logout.php');
} else{
	// for updating user info    
	if(isset($_POST['Submit'])) {
		$fname=$_POST['fname'];
		$lname=$_POST['lname'];
		$email=$_POST['email'];
		$contact=$_POST['contact'];
		$uid=intval($_GET['uid']);
		$query=mysqli_query($con,"update users set fname='$fname' ,lname='$lname' ,email='$email', contactno='$contact' where id='$uid'");
		$_SESSION['message'] = 'Profile Updated successfully.';
		$_SESSION['color'] = '#008000';
	}
?>
		<?php $ret = mysqli_query($con,"select * from users where id='".$_GET['uid']."'");
		while($row=mysqli_fetch_array($ret)) { ?>
			<section id="main-content">
				<section class="wrapper">
					<h3><i class="fa fa-angle-right"></i> <?php echo $row['fname'];?>'s Information</h3>
					<div class="row">
						<div class="col-md-12">
							<div class="content-panel">
								<p align="center" style="color:#F00;"><?php //echo $_SESSION['msg'];?><?php //echo $_SESSION['msg']=""; ?></p>
								<form class="form-horizontal style-form" name="form1" method="post" action="" onSubmit="return valid();">
									<?php if(isset($_SESSION['message'])) { ?>
										<p style="color:<?php echo $_SESSION['color'] ?>;margin-left: 25px;">
											<?php 
												echo $_SESSION['message']; 
												$_SESSION['message'] = ''; 
												$_SESSION['color'] = '';
											?>
										</p>
									<?php } ?>
									<div class="form-group">
										<label class="col-sm-2 col-sm-2 control-label" style="padding-left:40px;">First Name </label>
										<div class="col-sm-10">
											<input type="text" class="form-control" name="fname" value="<?php echo $row['fname'];?>" >
										</div>
									</div>

									<div class="form-group">
										<label class="col-sm-2 col-sm-2 control-label" style="padding-left:40px;">Last Ename</label>
										<div class="col-sm-10">
											<input type="text" class="form-control" name="lname" value="<?php echo $row['lname'];?>" >
										</div>
									</div>

									<div class="form-group">
										<label class="col-sm-2 col-sm-2 control-label" style="padding-left:40px;">Email </label>
										<div class="col-sm-10">
											<input type="text" class="form-control" name="email" value="<?php echo $row['email'];?>" >
										</div>
									</div>
									
									<div class="form-group">
										<label class="col-sm-2 col-sm-2 control-label" style="padding-left:40px;">Contact no. </label>
										<div class="col-sm-10">
											<input type="text" class="form-control" name="contact" value="<?php echo $row['contactno'];?>" >
										</div>
									</div>
									
									<div class="form-group">
										<label class="col-sm-2 col-sm-2 control-label" style="padding-left:40px;">Registration Date </label>
										<div class="col-sm-10">
											<input type="text" class="form-control" name="regdate" value="<?php echo $row['created_date'];?>" readonly >
										</div>
									</div>
									
									<div style="margin-left:100px;">
										<input type="submit" name="Submit" value="Update" class="btn btn-theme">
									</div>
									
								</form>
							</div>
						</div>
					</div>
				</section>
			<?php } ?>
		</section>
</body>
</html>
<?php } ?>