<?php include 'header.php'; ?>
<?php
	require_once('dbconnection.php');	
	
	$result = mysqli_query($con,"select * from blog order by id desc");
	
	$limit = 10;   
	if (isset($_GET["page"])) {
		$pn  = $_GET["page"];  
	}  
	else {
		$pn=1;  
	};   

	$start_from = ($pn-1) * $limit;	
	$result = mysqli_query($con,"select * from blog order by id desc LIMIT $start_from, $limit");		
?>

<!-- inner page banner -->
<div id="inner_banner" class="inner_banner_section">
  <div class="about-container">
    <div class="row">
      <div class="col-md-12">
        <div class="full">
          <div class="title-holder">
            <div class="title-holder-cell text-left">
              <h1 class="page-title">Blog</h1>
              <ol class="breadcrumb">
                <li><a href="index.php">Home</a></li>
                <li class="active">Blog</li>
              </ol>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- end inner page banner -->


<!-- list starts here -->
<section id="main-content">
	<section class="wrapper">			
			<?php while($row = $result->fetch_assoc()) { ?>
				<div class="row blog-item">
				<h1 class="title"><?php echo $row['title']; ?></h1>
				<p class="date">Posted on: <?php echo $row['date']; ?></p>
				<p class="description"><?php echo $row['description']; ?></p>
				</div>
			<?php	} ?>
			<ul class="pagination"> 
				<?php   
					$result = mysqli_query($con,"select count(*) from blog");
					$row = $result->fetch_row();							
					$total_records = $row[0];   
					$total_pages = ceil($total_records / $limit); 
					$k = (($pn+4>$total_pages)?$total_pages-4:(($pn-4<1)?5:$pn));
					$pagLink = ""; 
					if($pn>=2){
							echo "<li><a href='blog.php?page=1'> << </a></li>"; 
							echo "<li><a href='blog.php?page=".($pn-1)."'> < </a></li>"; 
					} 
					for ($i=-2; $i<=2; $i++) {
						if($k+$i >0 && $k+$i <= $total_pages){
							if($k+$i==$pn) 
								$pagLink .= "<li class='active'><a href='blog.php?page=".($k+$i)."'>".($k+$i)."</a></li>"; 
							else
								$pagLink .= "<li><a href='blog.php?page=".($k+$i)."'>".($k+$i)."</a></li>";
						}
					}
					echo $pagLink; 
					if($pn<$total_pages){ 
							echo "<li><a href='blog.php?page=".($pn+1)."'> > </a></li>"; 
							echo "<li><a href='blog.php?page=".$total_pages."'> >> </a></li>"; 
					}     
				?>
			</ul>
	</section>
</section>
<?php include 'footer.php'; ?>