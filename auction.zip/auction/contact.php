<?php include 'header.php'; 

if(isset($_POST['contact_submit'])) {
	require_once('dbconnection.php');	
	$first_name = $_POST['first_name'];
	$last_name = $_POST['last_name'];
	$email = $_POST['email'];
	$phone = $_POST['phone'];
	$message = $_POST['message'];
	
	$success = mysqli_query($con,"insert into `contact`(`first_name`, `last_name`, `email`, `phone`, `message`) values('$first_name','$last_name', '$email','$phone','$message')");
	
	if($success){
		$_SESSION['message'] = 'Registration successfull.';
		$_SESSION['color'] = '#008000';
	}
}

?>
<!-- inner page banner -->
<div id="inner_banner" class="inner_banner_section">
  <div class="about-container">
    <div class="row">
      <div class="col-md-12">
        <div class="full">
          <div class="title-holder">
            <div class="title-holder-cell text-left">
              <h1 class="page-title">Contact Us</h1>
              <ol class="breadcrumb">
                <li><a href="index.php">Home</a></li>
                <li class="active">Contact Us</li>
              </ol>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- end inner page banner -->

<div class="padding_layout_1 contact-container">
	<div class="contact-left">
		<h4>Address One</h4>
		<p>You can connect with us using the below mentioned contact details.</p>
		<div class="information_bottom left-side margin_bottom_20_all">
			<div class="icon_bottom"> <i class="fas fa-clock" aria-hidden="true"></i> </div>
			<div class="info_cont">
				<h4>Give us a call</h4>
				<p>+00 (123) 456 7890</p>
			</div>
		</div>
		<div class="information_bottom left-side margin_bottom_20_all">
			<div class="icon_bottom"> <i class="fas fa-phone" aria-hidden="true"></i> </div>
			<div class="info_cont">
				<h4>Send us a mail</h4>
				<p>support@domain.com</p>
			</div>
		</div>
		<div class="information_bottom left-side">
			<div class="icon_bottom"> <i class="fas fa-envelope" aria-hidden="true"></i> </div>
			<div class="info_cont">
				<h4>Mon. - Sat</h4>
				<p>08.00am - 8.00pm</p>
			</div>
		</div>
	</div>
	
	<div class="contact-right">
		<h4>Address Two</h4>
		<p>You can connect with us using the below mentioned social media.</p>
		<div class="information_bottom left-side margin_bottom_20_all">
			<div class="icon_bottom"> <i class="fab fa-facebook" aria-hidden="true"></i> </div>
			<div class="info_cont">
				<h4>Facebook</h4>
				<p>Sydney Australia</p>
			</div>
		</div>
		<div class="information_bottom left-side margin_bottom_20_all">
			<div class="icon_bottom"> <i class="fab fa-twitter" aria-hidden="true"></i> </div>
			<div class="info_cont">
				<h4>Twitter</h4>
				<p>Mon-Fri 8:30am-6:30pm</p>
			</div>
		</div>
		<div class="information_bottom left-side">
			<div class="icon_bottom"> <i class="fab fa-linkedin" aria-hidden="true"></i> </div>
			<div class="info_cont">
				<h4>LinkedIn</h4>
				<p>24/7 online support</p>
			</div>
		</div>
	</div>
</div>

<div class="contant_form">
	<h4 style="text-align:center;">GET IN TOUCH</h4>	
	<div class="form_section">
		<form class="form_contant" method="post" action="" enctype="multipart/form-data">
			<?php if(isset($_SESSION['message'])) { ?>
				<p style="color:<?php echo $_SESSION['color'] ?>;margin-left: 25px;">
					<?php 
						echo $_SESSION['message']; 
						$_SESSION['message'] = ''; 
						$_SESSION['color'] = '';
					?>
				</p>
			<?php } ?>
			<fieldset>
			<div class="form-row">
				<div class="field">
					<input class="field_custom" name="first_name" placeholder="First name" type="text" required />
				</div>
				<div class="field">
					<input class="field_custom" name="last_name" placeholder="Last name" type="text" required />
				</div>
				<div class="field">
					<input class="field_custom" name="email" placeholder="Email adress" type="email" required />
				</div>
				<div class="field">
					<input class="field_custom" name="phone" placeholder="10 Digit Phone number" pattern="[0-9]{10}" type="tel" required />
				</div>
				<div class="textbox">
					<textarea class="field_custom" name="message" placeholder="Messager" required ></textarea>
				</div>
				
				<div class="center"><input class="btn main_bt" type="submit" name="contact_submit"  value="Submit" ></div>
			</div>
			</fieldset>
		</form>
	</div>
</div>

<div class="modal fade" id="search_bar" role="dialog">
  <div class="modal-dialog">
    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
      </div>
    </div>
  </div>
</div>
<?php include 'footer.php'; ?>