<div class="wrapper row4">
  <footer id="footer" class="hoc clear">
    <div class="one_quarter first">
      <h1 class="logoname clear">Auction</h1>
      <p class="btmspace-30">India produces a wide range of spices and holds a prominent position in world spice production. Because of the varying climates - from tropical to sub-tropical to temperate-almost all spices grow splendidly in India.</p>
      
    </div>
    <div class="one_quarter">
      <h6 class="heading">Contact Us</h6>
      <ul class="nospace linklist contact">
        <li><i class="fas fa-map-marker-alt"></i>
          <address>
          Street Name &amp; Number, Town, Postcode/Zip
          </address>
        </li>
        <li><i class="fas fa-phone"></i> +91 9876543210</li>
        <li><i class="fas fa-fax"></i> +91 9876543210</li>
        <li><i class="far fa-envelope"></i> info@domain.com</li>
      </ul>
    </div>
    <div class="one_quarter">
      <h6 class="heading">Our services</h6>
      <ul class="nospace linklist">
        <li>Manage Auctioneers</li>
        <li>Guide the farmers</li>
        <li>Helping farmer</li>
        <li>Guiding Auctioneers</li>
      </ul>
    </div>
    <div class="one_quarter">
      <h6 class="heading">Who we are?</h6>
      <ul class="nospace linklist">
        <li>
          <article>
            <p class="nospace btmspace-10">The trading and export Division of the Company has been functioning at Bodinayakanur, Tamilnadu.</p>
          </article>
        </li>
        <li>
          <article>
            <p class="nospace btmspace-10">The area of operation of the trading Division has been spreading all over India.</p>
          </article>
        </li>
      </ul>
    </div>
  </footer>
</div>
<div class="wrapper row5">
  <div id="copyright" class="hoc clear">
    <p class="fl_left">Copyright &copy; 2021 - All Rights Reserved - <a href="#">Cardamom Auction Management</a></p>
  </div>
</div>
<!-- JAVASCRIPTS -->
<script src="layout/scripts/jquery.min.js"></script>
<script src="layout/scripts/jquery.mobilemenu.js"></script>
</body>
</html>