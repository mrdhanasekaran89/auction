<?php 
include 'header-admin.php';
session_start();
include'dbconnection.php';
if (strlen($_SESSION['id']==0)) {
	header('location:logout.php');
} else{
	// for updating price info    
	if(isset($_POST['Submit'])) {
		$date = $_POST['date'];
		$cardamom_type = $_POST['cardamom_type'];
		$minimum_price = $_POST['min_price'];
		$maximum_price = $_POST['max_price'];
		$average_price = $_POST['avg_price'];
		$no_of_kgs_sold = $_POST['no_of_kgs'];		
		
		$id = intval($_GET['id']);
		$query=mysqli_query($con,"update price set date='$date', cardamom_type='$cardamom_type', minimum_price='$minimum_price', maximum_price='$maximum_price', average_price='$average_price', no_of_kgs_sold='$no_of_kgs_sold' where id='$id'");
		$_SESSION['message'] = 'Price details Updated successfully.';
		$_SESSION['color'] = '#008000';
	}
?>
		<?php $ret = mysqli_query($con,"select * from price where id='".$_GET['id']."'");
		while($row=mysqli_fetch_array($ret)) { ?>
			<section id="main-content">
				<section class="wrapper">
					<h3><i class="fa fa-angle-right"></i> <?php echo 'Cardamom';?>'s Information</h3>
					<div class="row">
						<div class="col-md-12">
							<div class="content-panel">
								<form class="form-horizontal style-form" name="form1" method="post" action="" onSubmit="return valid();">
									<?php if(isset($_SESSION['message'])) { ?>
										<p style="color:<?php echo $_SESSION['color'] ?>;margin-left: 25px;">
											<?php 
												echo $_SESSION['message']; 
												$_SESSION['message'] = ''; 
												$_SESSION['color'] = '';
											?>
										</p>
									<?php } ?>
									<div class="form-group">
										<label class="col-sm-2 col-sm-2 control-label" style="padding-left:40px;">Date</label>
										<div class="col-sm-10">
											<input type="date" class="form-control" name="date" value="<?php echo $row['date'];?>" >
										</div>
									</div>

									<div class="form-group">
										<label class="col-sm-2 col-sm-2 control-label" style="padding-left:40px;">Cardamom Type</label>
										<div class="col-sm-10">
											<select name="cardamom_type" class="form-control" required>
												<option value="small" <?php if($row['cardamom_type'] == 'small') { echo 'selected'; } ?>>Small</option>
												<option value="big" <?php if($row['cardamom_type'] == 'big') { echo 'selected'; } ?>>Big</option>
											</select>
										</div>
									</div>

									<div class="form-group">
										<label class="col-sm-2 col-sm-2 control-label" style="padding-left:40px;">Minimum Price</label>
										<div class="col-sm-10">
											<input type="text" class="form-control" name="min_price" value="<?php echo $row['minimum_price'];?>" >
										</div>
									</div>
									
									<div class="form-group">
										<label class="col-sm-2 col-sm-2 control-label" style="padding-left:40px;">Maximum Price</label>
										<div class="col-sm-10">
											<input type="text" class="form-control" name="max_price" value="<?php echo $row['maximum_price'];?>" >
										</div>
									</div>
									
									<div class="form-group">
										<label class="col-sm-2 col-sm-2 control-label" style="padding-left:40px;">Average Price</label>
										<div class="col-sm-10">
											<input type="text" class="form-control" name="avg_price" value="<?php echo $row['average_price'];?>" >
										</div>
									</div>
									
									<div class="form-group">
										<label class="col-sm-2 col-sm-2 control-label" style="padding-left:40px;">No of KGs sold</label>
										<div class="col-sm-10">
											<input type="text" class="form-control" name="no_of_kgs" value="<?php echo $row['no_of_kgs_sold'];?>" >
										</div>
									</div>
									
									<div style="margin-left:100px;">
										<input type="submit" name="Submit" value="Update" class="btn btn-theme">
									</div>
									
								</form>
							</div>
						</div>
					</div>
				</section>
			<?php } ?>
		</section>
</body>
</html>
<?php } ?>