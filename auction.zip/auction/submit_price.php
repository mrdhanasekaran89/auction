<?php include 'header.php';

if (!isset($_SESSION['id'])) {
  header('location:logout.php');
} else{
	
if(isset($_POST['price_submit'])) {
	if(!is_numeric($_POST['min_price'])){
		$_SESSION['message'] = 'Minimum price should be a number.';
		$_SESSION['color'] = '#F00';
	}elseif(!is_numeric($_POST['max_price'])){
		$_SESSION['message'] = 'Maximum price should be a number.';
		$_SESSION['color'] = '#F00';
	}elseif(!is_numeric($_POST['avg_price'])){
		$_SESSION['message'] = 'Average price should be a number.';
		$_SESSION['color'] = '#F00';
	}elseif(!is_numeric($_POST['no_of_kgs'])){
		$_SESSION['message'] = 'Number of KGs sold should be a number.';
		$_SESSION['color'] = '#F00';
	}elseif($_POST['min_price'] > $_POST['avg_price']){
		$_SESSION['message'] = 'Average price should be less than Maximum price and greater that Minimum price.';
		$_SESSION['color'] = '#F00';
	}elseif($_POST['avg_price'] > $_POST['max_price']){
		$_SESSION['message'] = 'Average price should be less than Maximum price and greater that Minimum price.';
		$_SESSION['color'] = '#F00';
	}else {
		require_once('dbconnection.php');
	
		$user_id = $_SESSION['id'];
		$user_query = mysqli_query($con,"select * from users where id='$user_id'");
		
		while($row = $user_query->fetch_assoc()) {
			$auctioneer = $row['fname'].' '.$row['lname'];
			$uid = $row['id'];
		}
		
		$date = $_POST['date'];
		$cardamom_type = $_POST['cardamom_type'];
		$min_price = $_POST['min_price'];
		$max_price = $_POST['max_price'];
		$avg_price = $_POST['avg_price'];
		$no_of_kgs = $_POST['no_of_kgs'];
		
		$success = mysqli_query($con,"insert into `price`(`date`, `auctioneer`, `uid`, `cardamom_type`, `minimum_price`, `maximum_price`, `average_price`, `no_of_kgs_sold`) values('$date','$auctioneer', '$uid','$cardamom_type','$min_price','$max_price','$avg_price','$no_of_kgs')");
		
		if($success)
		{
			$_SESSION['message'] = 'Price details submitted successfull.';
			$_SESSION['color'] = '#008000';
		}
	}
	
}

?>

<!-- inner page banner -->
<div id="inner_banner" class="inner_banner_section">
  <div class="about-container">
    <div class="row">
      <div class="col-md-12">
        <div class="full">
          <div class="title-holder">
            <div class="title-holder-cell text-left">
              <h1 class="page-title">Submit cardamom price</h1>
              <ol class="breadcrumb">
                <li><a href="index.php">Home</a></li>
                <li class="active">Submit cardamom price</li>
              </ol>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- end inner page banner -->

<div class="submit-price-intro">
	<p>The Quality Evaluation Laboratory of Spices Board was established in 1989. It provides analytical services to the Indian spice industry, monitors the quality of spices produced and processed in the country and analyse all 
	the samples collected by the Board under the Compulsory inspection on Chillies, Chillies products and Turmeric powder exported from India.</p>
	
	<p>The Laboratory established its first Regional Quality Evaluation Laboratory at Mumbai during June 2008. 
	The second Regional Quality Evaluation Laboratory is established at Guntur, Andhra Pradesh during 2010. The third Regional Quality Evaluation Laboratory is established at Gummidipoondi, Chennai in 2011 and fourth in Narela,New Delhi in 2012 and the fifth one at Tuticorin in 2013.
	</p>
	<p>The Regional Laboratory at Mumbai is also accredited under NABL ( ISO/ IEC: 17025:2005) in 2011 and the Guntur Laboratory got the accreditation in 2013. 
	The Chennai, Tuticorin and the New Delhi Laboratory are also in the process of getting Accreditation under ISO/IEC: 17025:2005.
	</p>
</div>
    
		<!-- form starts here -->
		
<div class="custom_form">
	<form name="todays_price" class="todays_price" method="post" action="" enctype="multipart/form-data">
		<?php if(isset($_SESSION['message'])) { ?>
			<p style="color:<?php echo $_SESSION['color'] ?>;margin-left: 25px;">
				<?php 
					echo $_SESSION['message']; 
					$_SESSION['message'] = ''; 
					$_SESSION['color'] = '';
				?>
			</p>
		<?php } ?>
		<p>Date </p>
		<input type="date" class="text" value=""  name="date" required >
		<p>Cardamom Type </p>
			<select name="cardamom_type" class="text" required>
				<option value="small">Small</option>
				<option value="big">Big</option>
			</select>
		<p>Minimum Price</p>
		<input type="text" class="text" value="" name="min_price" required >
		<p>Maximum Price </p>
		<input type="text" class="text" value="" name="max_price" required >
		<p>Average Price </p>
		<input type="text" class="text" value="" name="avg_price" required >
		<p>No of KGs sold </p>
		<input type="text" value="" name="no_of_kgs" required>
		<div class="price-submit" style="margin:12px 0">
			<input type="submit" name="price_submit"  value="Submit" >
		</div>
	</form>
</div>
<?php } include 'footer.php'; ?>