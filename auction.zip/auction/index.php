<?php include 'header.php'; ?>

<div class="wrapper bgded overlay" style="background-image:url('images/demo/backgrounds/home-background.png');">
  <div id="pageintro" class="hoc clear">
    <article>
      <h3 class="heading">Cardamom Auction Management</h3>
      <footer>
        <ul class="nospace inline pushright">
          <li><a class="btn" href="about.php">About us</a></li>
          <li><a class="btn inverse" href="contact.php">Contact us</a></li>
        </ul>
      </footer>
    </article>
  </div>
</div>
<div class="wrapper row3">
  <main class="hoc container clear"> 
    <!-- main body -->
    <article class="group">
      <div class="one_half first">
        <h6 class="heading underline font-x2">Where are we functioning from?</h6>
        <p>The trading and export Division of the Company has been functioning at Bodinayakanur, Tamilnadu. While Kerala is the origin for most of the cardamom produced in India, processing and trading happen mostly in Tamilnadu, whereas Northern States are accounting for most of the cardamom consumed.</p>
				<p>The area of operation of the trading Division has been spreading all over India and the company is a notable exporter and regularly dispatching consignments of cardamom to Middle East Contries.</p>
        <footer><a class="btn" href="contact.php">Read More</a></footer>
      </div>
      <div class="one_half"><a class="imgover" href="contact.php"><img style="width: 480px; height: 300px;" class="borderedbox inspace-10" src="images/demo/cardamom-400300.png" alt=""></a></div>
    </article>
    <!-- / main body -->
    <div class="clear"></div>
  </main>
</div>
<div class="wrapper bgded overlay dark" style="background-image:url('images/demo/backgrounds/home-background.png');">
  <div id="shout" class="hoc container clear">
    <article>
      <h3 class="heading font-x2">How we are validating the quality of Cardamom?</h3>
      <p>Cardamom procured by farmers would undergo a series of quality tests, to meet international specifications and standards, without any compromise in quality. Moreover, as cardamom has been procured selectively from planters, at the own auctions of the company, the quality of cardamom has been ensured, at the time of procurement itself.</p>
    </article>
  </div>
</div>
<div class="wrapper row3">
  <section id="services" class="hoc container clear">
    <div class="center btmspace-80">
      <h6 class="heading underline font-x2">Our main focus areas</h6>
    </div>
    <ul class="nospace group">
      <li class="one_third">
        <article>
          <h6 class="heading">Who we are?</h6>
          <p>Allspice trees are evergreen medium sized, grow up to a height of 8 to 10 meters and with a slender upright trunk and smooth greyish bark.</p>
          <footer><a href="about.php"><i class="fas fa-arrow-right"></i></a></footer>
        </article>
      </li>
      <li class="one_third">
        <article>
          <h6 class="heading">Our services</h6>
          <p>Allspice trees are evergreen medium sized, grow up to a height of 8 to 10 meters and with a slender upright trunk and smooth greyish bark.</p>
          <footer><a href="services.php"><i class="fas fa-arrow-right"></i></a></footer>
        </article>
      </li>
      <li class="one_third">
        <article>
          <h6 class="heading">Contact us</h6>
          <p>With regard to purchase of cardamom and other issues relating to the trading division, Cumbum, contact can be made with the officials of the company.</p>
          <footer><a href="contact.php"><i class="fas fa-arrow-right"></i></a></footer>
        </article>
      </li>
    </ul>
  </section>
</div>
<?php include 'footer.php'; ?>